package com.hritik.dao;
import com.hritik.form.*;

import java.sql.SQLException;
import java.util.List;

public interface EmployeeDao {
	public List<Employee> getAllEmployee() throws SQLException;
    public Employee getEmployeeById(int eid) throws SQLException;
    public Employee getEmployeeByName(String ename) throws SQLException;
    public void addEmployee(Employee employee) throws SQLException;
    public void deleteEmployee(int eid) throws SQLException;
    public void updateEmployee(Employee employee, int eid) throws SQLException;
    public List<Employee> getEmployeeByDept(String dname) throws SQLException;
    public List<Employee> getEmployeeByManager(String ename) throws SQLException;
    public List<Employee> getAllManagers() throws SQLException;
    
}
