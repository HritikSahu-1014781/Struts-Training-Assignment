package com.hritik.form;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.validator.ValidatorForm;

public class MyEmployee extends ValidatorForm{
	private int id;
	private String name;
	private String email;
	private String mobile;
	private int age;
	public MyEmployee(int id, String name, String email, String mobile, int age) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.mobile = mobile;
		this.age = age;
	}
	public MyEmployee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "MyEmployee [id=" + id + ", name=" + name + ", email=" + email + ", mobile=" + mobile + ", age=" + age
				+ "]";
	}
//  @Override
//	public ActionErrors validate(ActionMapping mapping, HttpServletRequest request) {
//		 ActionErrors errors = new ActionErrors();
//	        //applying the validation that name cannot be null.
//	        if(this.name==null||this.name.trim()==""){
//	            errors.add("name" , new ActionMessage("form.name.required"));
//	        }
//	        if(this.name.trim().length()<=5){
//	            errors.add("name" , new ActionMessage("form.namesize.required",5));
//	        }
//	        if(this.age<18||this.age>60){
//	            errors.add("age" , new ActionMessage("form.age.required",18,60));
//	        }
//	        if(this.mobile.trim().length()<10 || this.mobile.trim().length()>10){
//	            errors.add("mobile" , new ActionMessage("form.mobile.required"));
//	        }
//	        return errors;
//	}

}
