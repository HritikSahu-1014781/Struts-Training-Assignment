package com.example.hritik.form;

import org.apache.struts.action.ActionForm;

public class User extends ActionForm {

	private String firstname;
	private String lastname;
	
	public User() {
		super();
	}

	public User(String firstname, String lastname) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	
}
