package com.hritik.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.hritik.daoImpl.AllEmployeesDaoImpl;
import com.hritik.daoImpl.SearchEmployeeDaoImpl;
import com.hritik.form.Employee;

public class SearchEmployeeAction extends Action {

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		List<Employee> employees;
		try {
			employees = new SearchEmployeeDaoImpl().searchEmployee((Employee)form);
			request.setAttribute("employees", employees);
			return mapping.findForward("searchEmployee");
		} catch (Exception ex) {
			System.out.print(ex.getMessage());
			return mapping.findForward("failure");
		}
	}
}
