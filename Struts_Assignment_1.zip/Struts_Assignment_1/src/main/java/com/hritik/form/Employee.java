package com.hritik.form;

import org.apache.struts.action.ActionForm;

public class Employee extends ActionForm {

	private int id;
	private String name;
	private int salary;
	private String email;
	private int age;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public Employee(int id, String name, int salary, String email, int age) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.email = email;
		this.age = age;
	}

	public Employee() {
		super();
	}

}
