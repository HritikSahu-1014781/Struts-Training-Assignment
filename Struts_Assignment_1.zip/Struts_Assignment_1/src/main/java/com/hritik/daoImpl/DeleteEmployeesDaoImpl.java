package com.hritik.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DeleteEmployeesDaoImpl {

	public boolean deleteEmployees(String[] nameList) {
		
		Connection con = ConnectionMaster.getConnection();
		for(int i=0; i<nameList.length;i++) {
			try {
				PreparedStatement pstm=con.prepareStatement("Delete from employee where id=?");
				pstm.setInt(1, Integer.parseInt(nameList[i]));
				pstm.execute();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return true;
	}
}
