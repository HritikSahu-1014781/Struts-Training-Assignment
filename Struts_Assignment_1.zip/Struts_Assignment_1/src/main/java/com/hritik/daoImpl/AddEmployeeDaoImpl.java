package com.hritik.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.hritik.form.Employee;

public class AddEmployeeDaoImpl{
	
	public boolean addEmployee(Employee employee) {
		
		Connection con = ConnectionMaster.getConnection();
		
		try {
			PreparedStatement pstm=con.prepareStatement("Insert into employee (name,salary,email,age) values(?,?,?,?)");
			pstm.setString(1, employee.getName());
			pstm.setInt(2, employee.getSalary());
			pstm.setString(3, employee.getEmail());
			pstm.setInt(4, employee.getAge());
			
			pstm.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	
		return true;
	}
}
