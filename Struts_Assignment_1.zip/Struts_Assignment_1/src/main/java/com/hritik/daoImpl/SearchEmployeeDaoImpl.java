package com.hritik.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.hritik.form.Employee;

public class SearchEmployeeDaoImpl {
	
	public List<Employee> searchEmployee(Employee employee) {
		
		Connection con=ConnectionMaster.getConnection();
		List<Employee> employees=new ArrayList<Employee>();
		try {
			PreparedStatement pstm=con.prepareStatement("Select * from employee where name=?");
			pstm.setString(1, employee.getName());
			System.out.println(employee.getName());
			ResultSet rs=pstm.executeQuery();
			while(rs.next()) {
				employees.add(new Employee(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getString(4),rs.getInt(5)));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return employees;
	}
}
