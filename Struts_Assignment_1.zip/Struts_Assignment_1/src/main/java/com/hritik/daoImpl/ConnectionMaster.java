package com.hritik.daoImpl;

import java.sql.*;

public class ConnectionMaster {

	public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/struts_assignment", "root", "root");

		} catch (SQLException ex) {
			System.out.print(ex.getMessage());
		} catch (ClassNotFoundException ex) {
			System.out.print(ex.getMessage());
		}
		return con;
	}

}
