package com.hritik.action;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.hritik.daoImpl.AllEmployeesDaoImpl;
import com.hritik.form.Employee;

public class NextEmployeeAction extends Action {

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		int count=0;
		List<Employee> employees;
		try {
			HttpSession session=request.getSession();
			session.setAttribute("count", );
			employees = new AllEmployeesDaoImpl().getAllEmployee();
			request.setAttribute("employee", employees.get(0));
			return mapping.findForward("allEmployees");
		} catch (Exception ex) {
			System.out.print(ex.getMessage());
			return mapping.findForward("failure");
		}
	}
}
