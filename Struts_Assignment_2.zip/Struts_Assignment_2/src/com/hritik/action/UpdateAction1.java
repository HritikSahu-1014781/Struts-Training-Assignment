package com.hritik.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.hritik.dao.EmployeeDaoImpl;
import com.hritik.form.Employee;
import com.hritik.form.UserDelete;

public class UpdateAction1 extends Action{

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("hello");
		int id=Integer.parseInt(request.getParameter("eid"));
		Employee user=(Employee)form;
		request.setAttribute("employee", new EmployeeDaoImpl().getEmployeeById(id));
		Employee e=new EmployeeDaoImpl().getEmployeeById(user.getEid());
		
		return mapping.findForward("success");
	}

}
