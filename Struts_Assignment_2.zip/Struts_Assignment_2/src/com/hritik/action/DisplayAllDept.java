package com.hritik.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.hritik.dao.DepartDaoImp;
import com.hritik.dao.UserDaoImpl;
import com.hritik.form.Department;
import com.hritik.form.User;

public class DisplayAllDept extends Action{

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Department dept=(Department) form;
			
				request.setAttribute("department",new DepartDaoImp().getAllDepartments());
				
		
			return mapping.findForward("success");
		
      }
}
 


