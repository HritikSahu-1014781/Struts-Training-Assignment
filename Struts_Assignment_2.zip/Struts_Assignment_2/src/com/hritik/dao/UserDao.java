package com.hritik.dao;

import java.sql.SQLException;
import java.util.List;

import com.hritik.form.*;

public interface UserDao {
	public List<User> getAllUser() throws SQLException;
}
