package com.hritik.form;

import org.apache.struts.action.ActionForm;

public class Department extends ActionForm {
  private int deptid;
  private String dname;
  private String city;
@Override
public String toString() {
	return "Department [deptid=" + deptid + ", dname=" + dname + ", city=" + city + "]";
}
public Department() {
	super();
	// TODO Auto-generated constructor stub
}
public Department(int deptid, String dname, String city) {
	super();
	this.deptid = deptid;
	this.dname = dname;
	this.city = city;
}
public int getDeptid() {
	return deptid;
}
public void setDeptid(int deptid) {
	this.deptid = deptid;
}
public String getDname() {
	return dname;
}
public void setDname(String dname) {
	this.dname = dname;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
}
