package com.hritik.form;

import org.apache.struts.action.ActionForm;

public class Employee extends ActionForm{

	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", deptid=" + deptid + ", salary=" + salary
				+ ", designation=" + designation + ", email=" + email + ", mgrid=" + mgrid + "]";
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int eid, String ename, int deptid, int salary, String designation, String email, int mgrid) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.deptid = deptid;
		this.salary = salary;
		this.designation = designation;
		this.email = email;
		this.mgrid = mgrid;
	}
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public int getDeptid() {
		return deptid;
	}
	public void setDeptid(int deptid) {
		this.deptid = deptid;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getMgrid() {
		return mgrid;
	}
	public void setMgrid(int mgrid) {
		this.mgrid = mgrid;
	}
	private int eid;
	private String ename;
	private int deptid;
	private int salary;
	private String designation;
	private String email;
	private int mgrid;
}
