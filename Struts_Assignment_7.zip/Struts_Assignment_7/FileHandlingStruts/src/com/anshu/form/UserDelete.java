package com.hritik.form;

import org.apache.struts.action.ActionForm;

public class UserDelete extends ActionForm{
 private int eid;

@Override
public String toString() {
	return "UserDelete [eid=" + eid + "]";
}

public UserDelete() {
	super();
	// TODO Auto-generated constructor stub
}

public UserDelete(int eid) {
	super();
	this.eid = eid;
}

public int getEid() {
	return eid;
}

public void setEid(int eid) {
	this.eid = eid;
}
}
