package com.hritik.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.hritik.form.Department;


public class DepartDaoImp implements DepartDao{

	@Override
	public List<Department> getAllDepartments() throws SQLException  {
		List<Department> department=new ArrayList<Department>();
		Connection conn= ConnectionMaster.getConnection();
		Statement st= conn.createStatement();
		ResultSet rs= st.executeQuery("select * from department");
		while(rs.next()){
			department.add(new Department(rs.getInt(1), rs.getString(2), rs.getString(3)));
		}
		//department.stream().forEach(e->System.out.println(e));
		return department;
		
	}

	@Override
	public Department getDeptById(int deptid) throws SQLException {
		Connection conn= ConnectionMaster.getConnection();
		PreparedStatement st= conn.prepareStatement("select * from department where deptid=?");
		
		st.setInt(1,deptid);
		Department d1=null;
		ResultSet rs=st.executeQuery();
		if(rs.next()){
			 d1 = new Department(rs.getInt(1), rs.getString(2), rs.getString(3));
		}
		 return d1;
	}

	@Override
	public void addDepartment(Department d) throws SQLException {
		 Connection conn=ConnectionMaster.getConnection();
		 PreparedStatement pst=conn.prepareStatement("insert into department(deptid, dname, city) value(?,?,?)");
		 pst.setInt(1, d.getDeptid());
		 pst.setString(2, d.getDname());
		 pst.setString(3, d.getCity());
		 pst.executeQuery();
	}

	@Override
	public void delectDepartment(int deptid) throws SQLException {
		Connection conn=ConnectionMaster.getConnection();
		 
		PreparedStatement pst=conn.prepareStatement("delete from department where deptid=?");
		pst.setInt(1, deptid);
		pst.executeUpdate();
	}

	@Override
	public void updateDepartment(String city,int deptid) throws SQLException {
		Connection conn=ConnectionMaster.getConnection();
		String query="update department set city='"+ city +"' where deptid=?";
		PreparedStatement pst=conn.prepareStatement(query);
		pst.setInt(1, deptid);
		pst.executeUpdate();
	}

	
	
 
}
