package com.hritik.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.hritik.dao.EmployeeDaoImpl;
import com.hritik.form.Employee;

public class EmployeeByName  extends Action{

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		Employee e=(Employee)form;
		request.setAttribute("employees",new EmployeeDaoImpl().getEmployeeByName(e.getEname()));
		return mapping.findForward("success");
	}

}
